import reFlop from "./src/index.vue";
import { withInstall } from "@pureadmin/utils";

/** 时间翻牌组件 */
export const ReFlop = withInstall(reFlop);

export default ReFlop;
