import typeIt from "./src/index";
import type { Options as TypeItOptions } from "typeit";

const TypeIt = typeIt;

export { TypeIt, TypeItOptions };

export default TypeIt;
