import reSeamlessScroll from "./src/index.vue";
import { withInstall } from "@pureadmin/utils";

/** 无缝滚动组件 */
export const ReSeamlessScroll = withInstall(reSeamlessScroll);

export default ReSeamlessScroll;
