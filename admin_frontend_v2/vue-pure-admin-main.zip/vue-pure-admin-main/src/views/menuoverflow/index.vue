<script setup lang="ts">
defineOptions({
  name: "MenuOverflow"
});
</script>

<template>
  <div>目录、菜单文字超出显示 Tooltip 文字提示</div>
</template>
