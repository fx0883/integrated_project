### 注意

- `vue-pure-admin` 从 `3.3.0` 版本之后（不包括 `3.3.0` 版本），大部分工具和 `hooks` 都集成到了 [@pureadmin/utils](https://pure-admin-utils.netlify.app/)
- [npm](https://www.npmjs.com/package/@pureadmin/utils)
- [文档代码地址](https://github.com/pure-admin/pure-admin-utils-docs)
